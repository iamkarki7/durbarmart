<?php $__env->startSection('content'); ?>

<div class="text-center">
    <img src="<?php echo e(asset('img/client-images/404 Error Page not Found with people connecting a plug-pana.svg')); ?>" alt="">
    
    
    
    <hr class="new-section-sm bord-no">
    <div class="pad-top"><a class="btn btn-primary" href="<?php echo e(env('APP_URL')); ?>"><?php echo e(__('Return Home')); ?></a></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.blank', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laragon\www\durbarmart\resources\views/errors/404.blade.php ENDPATH**/ ?>