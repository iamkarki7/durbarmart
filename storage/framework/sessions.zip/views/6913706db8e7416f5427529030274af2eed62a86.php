<?php
	echo $array['content'];
?>
<?php /**PATH G:\laragon\www\durbarmart\resources\views/emails/delivery_status.blade.php ENDPATH**/ ?>