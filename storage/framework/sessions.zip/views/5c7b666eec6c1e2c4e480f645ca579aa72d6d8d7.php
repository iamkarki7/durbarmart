<?php $__env->startSection('content'); ?>
    <section class="bg-white py-4" id="login_section">
        <div class="profile login">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 mx-auto">
                        <div class="text-center px-35 pt-3">
                            <h1 class="heading heading-4 strong-500">
                                Login to your account.
                            </h1>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-8 mx-auto">
                        <div class="card border-0">
                            <div class="px-md-5 px-3 py-3 py-lg-4">
                                <div class="">
                                    <form class="form-default" role="form" action="<?php echo e(route('login')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php if(\App\Addon::where('unique_identifier', 'otp_system')->first() != null && \App\Addon::where('unique_identifier', 'otp_system')->first()->activated): ?>
                                            <span><?php echo e(__('Use country code before number')); ?></span>
                                        <?php endif; ?>
                                        <div class="form-group">
                                            <div class="input-group input-group--style-1">
                                                <?php if(\App\Addon::where('unique_identifier', 'otp_system')->first() != null && \App\Addon::where('unique_identifier', 'otp_system')->first()->activated): ?>
                                                    <input type="text" class="form-control form-control-sm <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(__('Email Or Phone')); ?>" name="email" id="email">
                                                <?php else: ?>
                                                    <input type="email" class="form-control form-control-sm <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(__('Email')); ?>" name="email">
                                                <?php endif; ?>
                                                <span class="input-group-addon">
                                                    <i class="text-md la la-user"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="input-group input-group--style-1">
                                                <input type="password" class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Password')); ?>" name="password" id="password">
                                                <span class="input-group-addon">
                                                    <i class="text-md la la-lock"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-6">
                                                <div class="form-group">
                                                    <div class="checkbox pad-btm text-left">
                                                        <input id="demo-form-checkbox" class="magic-checkbox" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                                        <label for="demo-form-checkbox" class="text-sm">
                                                            <?php echo e(__('Remember Me')); ?>

                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-6 text-right">
                                                <a href="<?php echo e(route('password.request')); ?>" class="link link-xs link--style-3" style="color:#dc3545"><?php echo e(__('Forgot password?')); ?></a>
                                            </div>
                                        </div>
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-styled btn-base-1 btn-md w-100"><?php echo e(__('Login')); ?></button>
                                        </div>
                                    </form>
                                    <div class="fb-login-button" data-width="" data-size="large" data-button-type="continue_with" data-layout="default" data-auto-logout-link="false" data-use-continue-as="false"></div>
                                    
                                    <?php if(\App\BusinessSetting::where('type', 'google_login')->first()->value == 1 || \App\BusinessSetting::where('type', 'facebook_login')->first()->value == 1 || \App\BusinessSetting::where('type', 'twitter_login')->first()->value == 1): ?>
                                        <div class="or or--1 mt-3 text-center">
                                            <span>or</span>
                                        </div>
                                        <div>
                                        <?php if(\App\BusinessSetting::where('type', 'facebook_login')->first()->value == 1): ?>
                                        <a class="btn btn-styled btn-block btn-facebook btn-icon--2 btn-icon-left px-4 mb-3" href="<?php echo e(url('auth/facebook/redirect')); ?>" type="button"> 
                                            <i class="icon fa fa-facebook-f"></i>Facebook
                                        </a>
                                            
                                        <?php endif; ?>
                                        <?php if(\App\BusinessSetting::where('type', 'google_login')->first()->value == 1): ?>
                                            
                                            <a class="btn btn-styled btn-block btn-google btn-icon--2 btn-icon-left px-4 mb-3" href="<?php echo e(url('auth/google/redirect')); ?>" type="button"> 
                                                <i class="icon fa fa-google-plus"></i>Google
                            
                                            </a>
                                        <?php endif; ?>
                                        <?php if(\App\BusinessSetting::where('type', 'twitter_login')->first()->value == 1): ?>
                                            <a href="<?php echo e(route('social.login', ['provider' => 'twitter'])); ?>" class="btn btn-styled btn-block btn-twitter btn-icon--2 btn-icon-left px-4">
                                                <i class="icon fa fa-twitter"></i> <?php echo e(__('Login with Twitter')); ?>

                                            </a>
                                        <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="text-center px-35 pb-3">
                                <p class="text-md">
                                    <?php echo e(__('Need an account?')); ?> <a href="<?php echo e(route('user.registration')); ?>" class="strong-600"><?php echo e(__('Register Now')); ?></a>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 m-auto text-center">
                        <div class="image">
                            <img src="<?php echo e(asset('client-image/DurbarMart-Login.svg')); ?>" alt="">
                        </div>
                    </div>
                    <div class="col-12">
                <!-- Put This Section on 404error page -->
                    <section class="bg-white py-4" id="error_page">
      <div class="error">
          
      </div>
    </section>
    <!-- Put This Section on 404error page -->
                    </div>
                    <?php if(env("DEMO_MODE") == "On"): ?>
                        <div class="bg-white p-4 mx-auto mt-4">
                            <div class="">
                                <table class="table table-responsive table-bordered mb-0">
                                    <tbody>
                                        <tr>
                                            <td><?php echo e(__('Seller Account')); ?></td>
                                            <td><button class="btn btn-info" onclick="autoFillSeller()">Copy credentials</button></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e(__('Customer Account')); ?></td>
                                            <td><button class="btn btn-info" onclick="autoFillCustomer()">Copy credentials</button></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        function autoFillSeller(){
            $('#email').val('seller@example.com');
            $('#password').val('123456');
        }
        function autoFillCustomer(){
            $('#email').val('customer@example.com');
            $('#password').val('123456');
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laragon\www\durbarmart\resources\views/frontend/user_login.blade.php ENDPATH**/ ?>