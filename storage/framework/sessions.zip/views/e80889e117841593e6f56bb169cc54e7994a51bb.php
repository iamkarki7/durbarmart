<?php $__env->startSection('content'); ?>
    <?php
    $refund_request_addon = \App\Addon::where('unique_identifier', 'refund_request')->first();
    ?>
    <!-- Basic Data Tables -->
    <!--===================================================-->
    <div class="panel">
        <div class="panel-heading bord-btm clearfix pad-all h-100">
            <h3 class="panel-title pull-left pad-no"><?php echo e(__('Orders')); ?></h3>
            <div class="pull-right clearfix">
                <form class="" id="sort_orders" action="" method="GET">
                    <div class="box-inline pad-rgt pull-left">
                        <div class="select" style="min-width: 300px;">
                            <select class="form-control demo-select2" name="payment_type" id="payment_type"
                                onchange="sort_orders()">
                                <option value=""><?php echo e(__('Filter by Payment Status')); ?></option>
                                <option value="paid" <?php if(isset($payment_status)): ?> <?php if($payment_status == 'paid'): ?> selected <?php endif; ?> <?php endif; ?>>
                                    <?php echo e(__('Paid')); ?></option>
                                <option value="unpaid" <?php if(isset($payment_status)): ?> <?php if($payment_status == 'unpaid'): ?> selected <?php endif; ?>
                                    <?php endif; ?>><?php echo e(__('Un-Paid')); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="box-inline pad-rgt pull-left">
                        <div class="select" style="min-width: 300px;">
                            <select class="form-control demo-select2" name="delivery_status" id="delivery_status"
                                onchange="sort_orders()">
                                <option value=""><?php echo e(__('Filter by Deliver Status')); ?></option>
                                <option value="pending" <?php if(isset($delivery_status)): ?> <?php if($delivery_status == 'pending'): ?> selected <?php endif; ?>
                                    <?php endif; ?>><?php echo e(__('Pending')); ?></option>
                                <option value="on_review" <?php if(isset($delivery_status)): ?> <?php if($delivery_status == 'on_review'): ?> selected <?php endif; ?>
                                    <?php endif; ?>><?php echo e(__('On review')); ?></option>
                                <option value="on_delivery" <?php if(isset($delivery_status)): ?> <?php if($delivery_status == 'on_delivery'): ?> selected <?php endif; ?>
                                    <?php endif; ?>><?php echo e(__('On delivery')); ?></option>
                                <option value="delivered" <?php if(isset($delivery_status)): ?> <?php if($delivery_status == 'delivered'): ?> selected <?php endif; ?>
                                    <?php endif; ?>><?php echo e(__('Delivered')); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="box-inline pad-rgt pull-left">
                        <div class="" style="min-width: 200px;">
                            <input type="text" class="form-control" id="search" name="search"
                                <?php if(isset($sort_search)): ?> value="<?php echo e($sort_search); ?>" <?php endif; ?>
                                placeholder="Type Order code & hit Enter">
                        </div>
                    </div>
                </form>
                <button class="btn btn-primary" id="bulkDelBtn" onclick="deleteBulkData();">Delete</button>
                <button class="btn btn-primary" id="bulkDownloadBtn" onclick="downloadBulkInvoice();">Download
                    Invoice</button>
            </div>
        </div>
        <div class="panel-body">
            <form class="" id="sort_orders2" action="" method="GET">
                <input type="hidden" id="delivery_status2" name="delivery_status">
                <ul class="nav nav-pills">
                    <li role="presentation" class="sort_order2_li <?php if(!@isset($delivery_status)): ?> active <?php endif; ?>"><a
                            href="javascript:void(0);">All</a></li>
                    <li role="presentation"
                        class="sort_order2_li <?php if(isset($delivery_status)): ?> <?php if($delivery_status == 'pending'): ?> active <?php endif; ?> <?php endif; ?>"
                        value="pending"><a href="javascript:void(0);">Pending</a></li>
                    <li role="presentation"
                        class="sort_order2_li <?php if(isset($delivery_status)): ?> <?php if($delivery_status == 'on_review'): ?> active <?php endif; ?> <?php endif; ?>"
                        value="on_review"><a href="javascript:void(0);">On Review</a></li>
                    <li role="presentation"
                        class="sort_order2_li <?php if(isset($delivery_status)): ?> <?php if($delivery_status == 'on_delivery'): ?> active <?php endif; ?> <?php endif; ?>"
                        value="on_delivery"><a href="javascript:void(0);">On Delivery</a></li>
                    <li role="presentation"
                        class="sort_order2_li <?php if(isset($delivery_status)): ?> <?php if($delivery_status == 'delivered'): ?> active <?php endif; ?> <?php endif; ?>"
                        value="delivered"><a href="javascript:void(0);">Delivered</a></li>
                </ul>
            </form>
            <table class="table table-striped res-table mar-no" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="checkAll"></th>
                        <th>#</th>
                        <th><?php echo e(__('Order Code')); ?></th>
                        <th><?php echo e(__('Num. of Products')); ?></th>
                        <th><?php echo e(__('Customer')); ?></th>
                        <th><?php echo e(__('Amount')); ?></th>
                        <th><?php echo e(__('Delivery Status')); ?></th>
                        <th><?php echo e(__('Payment Method')); ?></th>
                        <th><?php echo e(__('Payment Status')); ?></th>
                        <?php if($refund_request_addon != null && $refund_request_addon->activated == 1): ?>
                            <th><?php echo e(__('Refund')); ?></th>
                        <?php endif; ?>
                        <th width="10%"><?php echo e(__('Options')); ?></th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $order = \App\Order::find($order_id->id);
                            // dd($order);
                            
                        ?>
                        
                        <?php if($order != null): ?>
                            <tr>
                                <td><input type="checkbox" value="<?php echo e($order->id); ?>" data-id="<?php echo e($order->id); ?>"
                                        name="orderID[]" class="rowCheck"></td>
                                <td>
                                    <?php echo e($key + 1 + ($orders->currentPage() - 1) * $orders->perPage()); ?>

                                </td>
                                <td>
                                    <?php echo e($order->code); ?> <?php if($order->viewed == 0): ?> <span class="pull-right badge badge-info"><?php echo e(__('New')); ?></span> <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e(count($order->orderDetails->whereIn('seller_id', (array)$admin_user_id))); ?>

                                </td>
                                <td>
                                    <?php if($order->user != null): ?>
                                        <?php echo e($order->user->name); ?>

                                    <?php else: ?>
                                        Guest (<?php echo e($order->guest_id); ?>)
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e(single_price($order->orderDetails->whereIn('seller_id', (array)$admin_user_id)->sum('price') + $order->orderDetails->whereIn('seller_id', (array)$admin_user_id)->sum('tax'))); ?>

                                </td>
                                <td>
                                    <?php
                                        $status = $order->orderDetails->first()->delivery_status;
                                    ?>
                                    <?php echo e(ucfirst(str_replace('_', ' ', $status))); ?>

                                </td>
                                <td>
                                    <?php echo e(ucfirst(str_replace('_', ' ', $order->payment_type))); ?>

                                </td>
                                <td>
                                    <span class="badge badge--2 mr-4">
                                        <?php if($order->payment_status == 'paid'): ?>
                                            <i class="bg-green"></i> Paid
                                        <?php else: ?>
                                            <i class="bg-red"></i> Unpaid
                                        <?php endif; ?>
                                    </span>
                                </td>
                                <?php if($refund_request_addon != null && $refund_request_addon->activated == 1): ?>
                                    <td>
                                        <?php if(count($order->refund_requests) > 0): ?>
                                            <?php echo e(count($order->refund_requests)); ?> Refund
                                        <?php else: ?>
                                            No Refund
                                        <?php endif; ?>
                                    </td>
                                <?php endif; ?>
                                <td>
                                    <div class="btn-group dropdown">
                                        <button class="btn btn-primary dropdown-toggle dropdown-toggle-icon"
                                            data-toggle="dropdown" type="button">
                                            <?php echo e(__('Actions')); ?> <i class="dropdown-caret"></i>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-right">
                                            <li><a
                                                    href="<?php echo e(route('orders.show', encrypt($order->id))); ?>"><?php echo e(__('View')); ?></a>
                                            </li>
                                            <li><a
                                                    href="<?php echo e(route('seller.invoice.download', $order->id)); ?>"><?php echo e(__('Download Invoice')); ?></a>
                                            </li>
                                            <li><a
                                                    onclick="confirm_modal('<?php echo e(route('orders.destroy', $order->id)); ?>');"><?php echo e(__('Delete')); ?></a>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="clearfix">
                <div class="pull-right">
                    <?php echo e($orders->appends(request()->input())->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        function sort_orders(el) {
            $('#sort_orders').submit();
        }
        $("#checkAll").click(function() {
            $(".rowCheck").prop('checked', $(this).prop('checked'));
        });

        function deleteBulkData() {
            var allIds = [];
            $(".rowCheck:checked").each(function() {
                allIds.push($(this).val());
            });
            if (allIds.length <= 0) {
                alert("Please select row.");
            } else {
                var check = confirm("Are you sure you want to perform bulk delete?");
                if (check == true) {
                    var join_checked_values = allIds.join(",");
                    $.ajax({
                        url: "<?php echo e(route('orders.bulkDelete')); ?>",
                        type: 'get',
                        data: {
                            'ids': join_checked_values
                        },
                        beforeSend: function() {
                            $(".myoverlay").css('display', 'block');
                        },
                        success: function(data) {
                            if (data['success']) {
                                $(".rowCheck:checked").each(function() {
                                    $(this).parents("tr").remove();
                                });
                                $(".myoverlay").css('display', 'none');
                                alert(data['success']);
                                
                               
                            } else if (data['error']) {
                                alert(data['error']);
                            } else {
                                alert('Whoops something went wrong');
                            }
                        },
                        error: function(data) {
                            alert(data.responseText);
                        },
                        complete: function() {

                        }
                    });
                    $.each(allIds, function(index, value) {
                        $('table tr').filter("[data-row-id='" + value + "']").remove();
                    });
                }
            }
        }



        function downloadBulkInvoice() {
            var allIds = [];
            $(".rowCheck:checked").each(function() {
                allIds.push($(this).val());
            });
            if (allIds.length <= 0) {
                alert("Please select row.");
            } else {
                var check = confirm("Are you sure you want to perform bulk download?");
                if (check == true) {
                    var join_checked_values = allIds.join(",");
                    $.ajax({
                        url: "<?php echo e(route('orders.downloadInvoice')); ?>",
                        type: 'get',
                        data: {
                            'ids': join_checked_values
                        },
                        xhrFields: {
                            responseType: 'blob',
                        },
                        beforeSend: function() {
                            $(".myoverlay").css('display', 'block');
                        },
                        success: function(data) {
                            var blob = new Blob([data], {
                                type: 'application/pdf'
                            });
                            console.log(blob);
                            var link = document.createElement('a');
                            link.href = window.URL.createObjectURL(blob);
                            link.download = "OrderInvoices.pdf";
                            link.click();
                           
                            $(".myoverlay").css('display', 'none');
                            alert('Invoice has been downloaded successfully');
                            $(".rowCheck").prop('checked', false);
                        },
                        error: function(data) {

                        }
                    });

                }
            }
        }

        function downloadFile(response) {
            var blob = new Blob([response], {
                type: 'application/pdf'
            })
            var url = URL.createObjectURL(blob);
            location.assign(url);
        }

        function downloadPdf(response) {
            var blob = new Blob([response]);
            var link = document.createElement('a');
            link.href = window.URL.createObjectURL(blob);
            link.download = "Sample.pdf";
            link.click();
        }
        $(document).ready(function() {
            $('.sort_order2_li').on('click', function() {
                $('#delivery_status2').val($(this).attr('value'));
                $('#sort_orders2').submit();
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laragon\www\durbarmart\resources\views/orders/seller-orders.blade.php ENDPATH**/ ?>