<?php
	echo $array['content'];
?>
<?php /**PATH G:\laragon\www\durbarmart\resources\views/emails/invoice.blade.php ENDPATH**/ ?>