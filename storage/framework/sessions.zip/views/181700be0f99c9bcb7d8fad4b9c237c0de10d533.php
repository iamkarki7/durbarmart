<a href="<?php echo e(route('compare')); ?>" class="nav-box-link">
    
    <img data-toggle="tooltip" data-placement="top" title="Compare" src="<?php echo e(asset('frontend/images/coma.svg')); ?>" alt="cart-logo" class="img-fluid img_sag">
    
    <?php if(Session::has('compare')): ?>
        <sup class="nav-box-number"><?php echo e(count(Session::get('compare'))); ?></sup>
    <?php else: ?>
        <sup class="nav-box-number">0</sup>
    <?php endif; ?>
</a>
<?php /**PATH G:\laragon\www\durbarmart\resources\views/frontend/partials/compare.blade.php ENDPATH**/ ?>