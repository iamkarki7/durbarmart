<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    

<?php $__env->startSection('meta_title'); ?><?php echo e($page->meta_title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('meta_description'); ?><?php echo e($page->meta_description); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('meta_keywords'); ?><?php echo e($page->tags); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('meta'); ?>
    <!-- Schema.org markup for Google+ -->
    <meta itemprop="name" content="<?php echo e($page->meta_title); ?>">
    <meta itemprop="description" content="<?php echo e($page->meta_description); ?>">
    <meta itemprop="image" content="<?php echo e(asset($page->meta_img)); ?>">

    <!-- Twitter Card data -->
    <meta name="twitter:card" content="product">
    <meta name="twitter:site" content="@publisher_handle">
    <meta name="twitter:title" content="<?php echo e($page->meta_title); ?>">
    <meta name="twitter:description" content="<?php echo e($page->meta_description); ?>">
    <meta name="twitter:creator" content="@author_handle">
    <meta name="twitter:image" content="<?php echo e(asset($page->meta_img)); ?>">
    <meta name="twitter:data1" content="<?php echo e(single_price($page->unit_price)); ?>">
    <meta name="twitter:label1" content="Price">

    <!-- Open Graph data -->
    <meta property="og:title" content="<?php echo e($page->meta_title); ?>" />
    <meta property="og:type" content="product" />
    <meta property="og:url" content="<?php echo e(route('product', $page->slug)); ?>" />
    <meta property="og:image" content="<?php echo e(asset($page->meta_img)); ?>" />
    <meta property="og:description" content="<?php echo e($page->meta_description); ?>" />
    <meta property="og:site_name" content="<?php echo e(env('APP_NAME')); ?>" />
    <meta property="og:price:amount" content="<?php echo e(single_price($page->unit_price)); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col">
                <ul class="breadcrumb">
                    <li><a href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a></li>
                    <li><a href="<?php echo e(route('custom-pages.show_custom_page', $page->slug)); ?>"><?php echo e(__($page->title)); ?></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<section class="gry-bg py-4">
    <div class="container sm-px-0">
        <form class="" id="search-form" action="<?php echo e(route('search')); ?>" method="GET">
            <div class="row">
                <div class="col-xl-3 side-filter d-xl-block">
                    <div class="filter-overlay filter-close"></div>
                    <div class="filter-wrapper c-scrollbar">
                        <div class="filter-title d-flex d-xl-none justify-content-between pb-3 align-items-center">
                            <h3 class="h6">Filters</h3>
                            <button type="button" class="close filter-close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="bg-white sidebar-box mb-3">
                            <div class="box-title text-center">
                                <?php echo e(__('Custom Pages')); ?>

                            </div>
                            
                            <div class="box-content">
                                <div class="category-filter">
                                    <ul>
                                        <?php $__currentLoopData = \App\Page::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class=""><a href="<?php echo e(route('custom-pages.show_custom_page', $page_list->slug)); ?>"><?php echo e(__($page_list->title)); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-9 ">
                    <?php echo $page->content; ?>

                </div>
            </div>
        </form>
    </div>
</section>
<?php if(!empty($page->category_id)): ?>
<section class="mb-4">
    <div class="container">
        <div class="px-2 py-4 p-md-4 bg-white shadow-sm">
            <div class="section-title-1 clearfix">
                <h3 class="heading-5 strong-700 mb-0 float-lg-left">
                    <span class="mr-4">
                        <?php
                            $category=\App\Category::where('id',$page->category_id)->first();
                            ?>
                        <?php echo e($category->name); ?>

                    </span>
                </h3>
                <ul class="inline-links float-lg-right nav mt-3 mb-2 m-lg-0">
                    <li><a href="<?php echo e(route('products.category', $category->slug)); ?>" class="active">View More</a></li>
                    
                </ul>
            </div>
            <?php 
                $pages=\App\Page::where('id',$page->id)->first();
                $array = explode('!!', $pages->product_id);
                
            ?>
            <div class="caorusel-box arrow-round gutters-5">
                <div class="slick-carousel" data-slick-items="6" data-slick-xl-items="5" data-slick-lg-items="4"  data-slick-md-items="3" data-slick-sm-items="2" data-slick-xs-items="2">
                    <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $product=\App\Product::where('id',$array[$key])->first(); ?>
                    <div class="caorusel-card">
                        <div class="product-box-2 bg-white alt-box my-2">
                            <div class="position-relative overflow-hidden">
                                <a href="<?php echo e(route('product', $product->slug)); ?>" class="d-block product-image h-100 text-center">
                                    <img class="img-fit lazyload" src="<?php echo e(asset('frontend/images/placeholder.jpg')); ?>" data-src="<?php echo e(asset(json_decode($product->photos)[0])); ?>" alt="<?php echo e(__($product->name)); ?>">
                                </a>
                                <div class="product-btns clearfix">
                                    <button class="btn add-wishlist" title="Add to Wishlist" onclick="addToWishList(<?php echo e($product->id); ?>)" tabindex="0">
                                        <i class="la la-heart-o"></i>
                                    </button>
                                    <button class="btn add-compare" title="Add to Compare" onclick="addToCompare(<?php echo e($product->id); ?>)" tabindex="0">
                                        <i class="la la-refresh"></i>
                                    </button>
                                    <button class="btn quick-view" title="Quick view" onclick="showAddToCartModal(<?php echo e($product->id); ?>)" tabindex="0">
                                        <i class="la la-eye"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="p-md-3 p-2">
                                <div class="price-box">
                                    <?php if(home_base_price($product->id) != home_discounted_base_price($product->id)): ?>
                                        <del class="old-product-price strong-400"><?php echo e(home_base_price($product->id)); ?></del>
                                    <?php endif; ?>
                                    <span class="product-price strong-600"><?php echo e(home_discounted_base_price($product->id)); ?></span>
                                </div>
                                <div class="star-rating star-rating-sm mt-1">
                                    <?php echo e(renderStarRating($product->rating)); ?>

                                </div>
                                <h2 class="product-title p-0">
                                    <a href="<?php echo e(route('product', $product->slug)); ?>" class=" text-truncate"><?php echo e(__($product->name)); ?></a>
                                </h2>
                                <?php if(\App\Addon::where('unique_identifier', 'club_point')->first() != null && \App\Addon::where('unique_identifier', 'club_point')->first()->activated): ?>
                                    <div class="club-point mt-2 bg-soft-base-1 border-light-base-1 border">
                                        <?php echo e(__('Club Point')); ?>:
                                        <span class="strong-700 float-right"><?php echo e($product->earn_point); ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </div>
    </div>
</section>
<?php endif; ?>

<?php if(!empty($page->brand_id)): ?>    
<?php 
    $brand=\App\Brand::where('id',$page->brand_id)->first();
?>
<section class="mb-4">
    <div class="container">
        <div class="px-2 py-4 p-md-4 bg-white shadow-sm">
            <div class="section-title-1 clearfix">
                <h3 class="heading-5 strong-700 mb-0 float-lg-left">
                    <span class="mr-4">
                        Products From <?php echo e($brand->name); ?>

                    </span>
                </h3>
                <ul class="inline-links float-lg-right nav mt-3 mb-2 m-lg-0">
                    <li><a href="<?php echo e(route('brands.all')); ?>" class="active">View More</a></li>
                </ul>
            </div>
            <?php 
                $products=\App\Product::where('brand_id',$page->brand_id)->get();
            ?>
            <div class="caorusel-box arrow-round gutters-5">
                <div class="slick-carousel" data-slick-items="6" data-slick-xl-items="5" data-slick-lg-items="4"  data-slick-md-items="3" data-slick-sm-items="2" data-slick-xs-items="2">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="caorusel-card">
                        <div class="product-box-2 bg-white alt-box my-2">
                            <div class="position-relative overflow-hidden">
                                <a href="<?php echo e(route('product', $product->slug)); ?>" class="d-block product-image h-100 text-center">
                                    <img class="img-fit lazyload" src="<?php echo e(asset('frontend/images/placeholder.jpg')); ?>" data-src="<?php echo e(asset(json_decode($product->photos)[0])); ?>" alt="<?php echo e(__($product->name)); ?>">
                                </a>
                                <div class="product-btns clearfix">
                                    <button class="btn add-wishlist" title="Add to Wishlist" onclick="addToWishList(<?php echo e($product->id); ?>)" tabindex="0">
                                        <i class="la la-heart-o"></i>
                                    </button>
                                    <button class="btn add-compare" title="Add to Compare" onclick="addToCompare(<?php echo e($product->id); ?>)" tabindex="0">
                                        <i class="la la-refresh"></i>
                                    </button>
                                    <button class="btn quick-view" title="Quick view" onclick="showAddToCartModal(<?php echo e($product->id); ?>)" tabindex="0">
                                        <i class="la la-eye"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="p-md-3 p-2">
                                <div class="price-box">
                                    <?php if(home_base_price($product->id) != home_discounted_base_price($product->id)): ?>
                                        <del class="old-product-price strong-400"><?php echo e(home_base_price($product->id)); ?></del>
                                    <?php endif; ?>
                                    <span class="product-price strong-600"><?php echo e(home_discounted_base_price($product->id)); ?></span>
                                </div>
                                <div class="star-rating star-rating-sm mt-1">
                                    <?php echo e(renderStarRating($product->rating)); ?>

                                </div>
                                <h2 class="product-title p-0">
                                    <a href="<?php echo e(route('product', $product->slug)); ?>" class=" text-truncate"><?php echo e(__($product->name)); ?></a>
                                </h2>
                                <?php if(\App\Addon::where('unique_identifier', 'club_point')->first() != null && \App\Addon::where('unique_identifier', 'club_point')->first()->activated): ?>
                                    <div class="club-point mt-2 bg-soft-base-1 border-light-base-1 border">
                                        <?php echo e(__('Club Point')); ?>:
                                        <span class="strong-700 float-right"><?php echo e($product->earn_point); ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </div>
    </div>
</section>
<?php endif; ?>

<?php if(!empty($page->seller_id)): ?>
<?php 
    $user=\App\User::where('id',$page->seller_id)->first();
    $products=\App\Product::where('user_id',$user->id)->get();
?>
<section class="mb-4">
    <div class="container">
        <div class="px-2 py-4 p-md-4 bg-white shadow-sm">
            <div class="section-title-1 clearfix">
                <h3 class="heading-5 strong-700 mb-0 float-lg-left">
                    <span class="mr-4">
                        Products From <?php echo e($user->name); ?>

                    </span>
                </h3>
                
            </div>
            
            <div class="caorusel-box arrow-round gutters-5">
                <div class="slick-carousel" data-slick-items="6" data-slick-xl-items="5" data-slick-lg-items="4"  data-slick-md-items="3" data-slick-sm-items="2" data-slick-xs-items="2">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="caorusel-card">
                        <div class="product-box-2 bg-white alt-box my-2">
                            <div class="position-relative overflow-hidden">
                                <a href="<?php echo e(route('product', $product->slug)); ?>" class="d-block product-image h-100 text-center">
                                    <img class="img-fit lazyload" src="<?php echo e(asset('frontend/images/placeholder.jpg')); ?>" data-src="<?php echo e(asset(json_decode($product->photos)[0])); ?>" alt="<?php echo e(__($product->name)); ?>">
                                </a>
                                <div class="product-btns clearfix">
                                    <button class="btn add-wishlist" title="Add to Wishlist" onclick="addToWishList(<?php echo e($product->id); ?>)" tabindex="0">
                                        <i class="la la-heart-o"></i>
                                    </button>
                                    <button class="btn add-compare" title="Add to Compare" onclick="addToCompare(<?php echo e($product->id); ?>)" tabindex="0">
                                        <i class="la la-refresh"></i>
                                    </button>
                                    <button class="btn quick-view" title="Quick view" onclick="showAddToCartModal(<?php echo e($product->id); ?>)" tabindex="0">
                                        <i class="la la-eye"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="p-md-3 p-2">
                                <div class="price-box">
                                    <?php if(home_base_price($product->id) != home_discounted_base_price($product->id)): ?>
                                        <del class="old-product-price strong-400"><?php echo e(home_base_price($product->id)); ?></del>
                                    <?php endif; ?>
                                    <span class="product-price strong-600"><?php echo e(home_discounted_base_price($product->id)); ?></span>
                                </div>
                                <div class="star-rating star-rating-sm mt-1">
                                    <?php echo e(renderStarRating($product->rating)); ?>

                                </div>
                                <h2 class="product-title p-0">
                                    <a href="<?php echo e(route('product', $product->slug)); ?>" class=" text-truncate"><?php echo e(__($product->name)); ?></a>
                                </h2>
                                <?php if(\App\Addon::where('unique_identifier', 'club_point')->first() != null && \App\Addon::where('unique_identifier', 'club_point')->first()->activated): ?>
                                    <div class="club-point mt-2 bg-soft-base-1 border-light-base-1 border">
                                        <?php echo e(__('Club Point')); ?>:
                                        <span class="strong-700 float-right"><?php echo e($product->earn_point); ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </div>
    </div>
</section> 
   
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laragon\www\durbarmart\resources\views/frontend/custom_page.blade.php ENDPATH**/ ?>